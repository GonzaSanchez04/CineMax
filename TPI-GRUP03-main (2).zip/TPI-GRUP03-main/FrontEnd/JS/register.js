// Función de validación y envío del formulario
function validateForm(event) {
    event.preventDefault(); // Prevenir que se envíe el formulario antes de validar

    // Obtener valores de los campos
    const nombre = document.getElementById('nombre').value.trim();
    const apellido = document.getElementById('apellido').value.trim();
    const dni = document.getElementById('dni').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const tipoDni = document.getElementById('tipoDni').value.trim();
    const fechaNacimiento = document.getElementById('fechaNacimiento').value.trim();
    const calle = document.getElementById('calle').value.trim();
    const barrio = document.getElementById('barrio').value.trim();
    const numero = document.getElementById('numero').value.trim();
    const contraseña = document.getElementById('contraseña').value.trim();
    const confirmarContraseña = document.getElementById('confirmarContraseña').value.trim();

    // Validaciones
    if (!nombre || !apellido || !dni || !correo || !tipoDni || !fechaNacimiento || !calle || !barrio || !numero || !contraseña || !confirmarContraseña) {
        alert('Por favor, complete todos los campos.');
        return;
    }

    if (contraseña !== confirmarContraseña) {
        alert('Las contraseñas no coinciden.');
        return;
    }

    // Enviar los datos al servidor
    const formData = {
        nombre, apellido, dni, correo, tipoDni, fechaNacimiento, calle, barrio, numero, contraseña
    };

    fetch('http://localhost:7170/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
    })
    .catch(error => {
        console.error('Error al registrar:', error);
        alert('Hubo un error al registrar');
    });
}

// Asignar el evento de validación al formulario
const form = document.querySelector('form');
form.addEventListener('submit', validateForm);
