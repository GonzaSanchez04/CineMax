const express = require('express');
const path = require('path');
const app = express();
const port = 7170;

// Servir archivos estáticos desde la carpeta 'FrontEnd'
app.use(express.static(path.join(__dirname, '..', '..', 'FrontEnd')));

// Ruta para el formulario de registro
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '..', '..', 'FrontEnd', 'PAGES', 'register.html'));
});

// Endpoint de ejemplo para el registro
app.post('/register', (req, res) => {
    const user = req.body;
    console.log('Usuario registrado:', user);
    res.json({ success: true });
});

app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});
