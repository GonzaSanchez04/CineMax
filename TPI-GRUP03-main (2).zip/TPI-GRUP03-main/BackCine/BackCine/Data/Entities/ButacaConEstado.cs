﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackCine.Data.Entities
{
    public class ButacaConEstado
    {
        public int IdButaca { get; set; }
        public int NroButaca { get; set; }
        public int Estado { get; set; }
    }
}
